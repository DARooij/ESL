#include <error.h>
#include <fcntl.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/mman.h>
#include <unistd.h>
#include <stdbool.h>

#include "soc_system.h"

int main(int argc, char** argv) {
	int fd = 0;
	fd = open("/dev/mem", O_RDWR | O_SYNC);
	if (fd < 0) {
		perror("Couldn't open /dev/mem\n");
		return -1;
	}
	uint8_t* esl_demo_map = NULL;
	esl_demo_map = (uint8_t*)mmap(NULL, HPS_0_ARM_A9_0_QUAD_0_SPAN, PROT_READ | PROT_WRITE, MAP_SHARED, fd, HPS_0_ARM_A9_0_QUAD_0_BASE);
	if (esl_demo_map == MAP_FAILED) {
		perror("Couldn't map bridge.");
		close(fd);
		return -1;
	}

	// *((uint32_t *)esl_demo_map) = 1 << 31 | 0x08;


	while(1) {
		uint32_t data = *((uint32_t *)esl_demo_map);
		uint16_t value = *((uint16_t *)esl_demo_map);
		bool left = (bool)((data) & (1 << 16));
		bool right = (bool)((data) & (1 << 17));
		printf("Left: %d\n", left);
		printf("Right: %d\n", right);
		printf("Count: 0x%04x (%d)\n", value, value);
	}
	
	close(fd);
	return 0;
}
